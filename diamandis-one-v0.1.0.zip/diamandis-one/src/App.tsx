import { useState } from "react";
import {
  AppWindow, ArrowUpRight, Boxes, CheckCircle2, ChevronRight, CircleHelp,
  Clock3, Command, FileSearch, FolderKanban, Gamepad2, HardDrive,
  Image, LayoutDashboard, Search, Settings2, ShieldCheck, Sparkles,
  Wrench, Zap
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { invoke } from "@tauri-apps/api/core";
import type { ModuleId } from "./types";

type NavItem = { id: ModuleId; label: string; icon: LucideIcon; group: string };

const nav: NavItem[] = [
  { id: "overview", label: "Visão geral", icon: LayoutDashboard, group: "WORKSPACE" },
  { id: "files", label: "File Manager", icon: FolderKanban, group: "WORKSPACE" },
  { id: "toolbox", label: "Toolbox", icon: Wrench, group: "WORKSPACE" },
  { id: "games", label: "GameHub", icon: Gamepad2, group: "GAMING" },
  { id: "saves", label: "Save Center", icon: HardDrive, group: "GAMING" },
  { id: "settings", label: "Configurações", icon: Settings2, group: "SYSTEM" }
];

const descriptions: Record<ModuleId, { title: string; subtitle: string }> = {
  overview: { title: "Seu espaço. Seu controle.", subtitle: "Tudo organizado, em um só lugar." },
  files: { title: "File Manager", subtitle: "Encontre, organize e entenda seus arquivos." },
  toolbox: { title: "Toolbox", subtitle: "Pequenas ferramentas para tarefas do dia a dia." },
  games: { title: "GameHub", subtitle: "Sua biblioteca gamer em um só lugar." },
  saves: { title: "Save Center", subtitle: "Proteja seus progressos com backups organizados." },
  settings: { title: "Configurações", subtitle: "Personalize sua experiência no DIAMANDIS ONE." }
};

function App() {
  const [active, setActive] = useState<ModuleId>("overview");
  const [search, setSearch] = useState("");
  const [diagnostic, setDiagnostic] = useState("Verificação ainda não executada");

  const runDiagnostic = async () => {
    try {
      const result = await invoke<string>("core_diagnostic");
      setDiagnostic(result);
    } catch {
      setDiagnostic("Modo de pré-visualização: execute pelo Tauri para acessar o núcleo Rust.");
    }
  };

  const current = descriptions[active];
  const filtered = nav.filter(item => item.label.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Command size={21} strokeWidth={1.8} /></div>
          <div><div className="brand-name">DIAMANDIS<span> ONE</span></div><div className="brand-caption">PERSONAL DESKTOP HUB</div></div>
        </div>

        <div className="sidebar-search">
          <Search size={15} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Encontrar módulo..." />
          <kbd>⌘ K</kbd>
        </div>

        {["WORKSPACE", "GAMING", "SYSTEM"].map(group => (
          <div className="nav-group" key={group}>
            <div className="nav-heading">{group}</div>
            {filtered.filter(item => item.group === group).map(item => {
              const Icon = item.icon;
              return <button key={item.id} className={`nav-item ${active === item.id ? "active" : ""}`} onClick={() => setActive(item.id)}>
                <Icon size={17} /><span>{item.label}</span>{active === item.id && <ChevronRight size={14} className="nav-chevron" />}
              </button>;
            })}
          </div>
        ))}

        <div className="sidebar-bottom">
          <div className="local-card"><div className="local-icon"><ShieldCheck size={17} /></div><div><strong>Local-first</strong><span>Seus dados ficam no seu PC</span></div><CheckCircle2 size={14} className="local-check" /></div>
          <div className="version">DIAMANDIS ONE <span>v0.1.0</span></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb"><span>DIAMANDIS ONE</span><ChevronRight size={13}/><strong>{current.title}</strong></div>
          <div className="top-actions"><span className="system-status"><i/> SISTEMA PRONTO</span><button className="icon-button" title="Ajuda"><CircleHelp size={17}/></button><div className="avatar">D</div></div>
        </header>

        <div className="content">
          <section className="welcome">
            <div><div className="eyebrow"><Sparkles size={13}/> CENTRAL DE COMANDO</div><h1>{current.title}</h1><p>{current.subtitle}</p></div>
            <div className="welcome-orb"><div className="orb-core"><Command size={29}/></div></div>
          </section>

          {active === "overview" ? <>
            <section className="hero-card">
              <div className="hero-copy"><div className="hero-tag"><Zap size={13}/> UM HUB. MÚLTIPLAS POSSIBILIDADES.</div><h2>Seu Windows,<br/><em>do seu jeito.</em></h2><p>Organização, produtividade e universo gamer reunidos em uma experiência única.</p><button className="primary-button" onClick={() => setActive("files")}>Explorar módulos <ArrowUpRight size={16}/></button></div>
              <div className="hero-art"><div className="ring ring-one"/><div className="ring ring-two"/><div className="hero-glyph"><Boxes size={62} strokeWidth={1}/></div><div className="float-chip chip-a"><FolderKanban size={15}/> Arquivos</div><div className="float-chip chip-b"><Gamepad2 size={15}/> GameHub</div><div className="float-chip chip-c"><Wrench size={15}/> Toolbox</div></div>
            </section>

            <div className="section-title"><div><h3>Seu workspace</h3><p>Escolha por onde começar</p></div><span className="section-count">03 MÓDULOS</span></div>
            <section className="module-grid">
              <ModuleCard icon={FolderKanban} title="File Manager" desc="Organize arquivos, encontre duplicados e tenha controle sobre seu armazenamento." meta="ORGANIZAÇÃO" onClick={() => setActive("files")}/>
              <ModuleCard icon={Wrench} title="Toolbox" desc="Conversores, ferramentas de imagem, texto e utilidades rápidas." meta="PRODUTIVIDADE" onClick={() => setActive("toolbox")}/>
              <ModuleCard icon={Gamepad2} title="GameHub" desc="Sua coleção de jogos, launchers, favoritos e sessões." meta="GAMING" onClick={() => setActive("games")}/>
            </section>

            <div className="section-title lower-title"><div><h3>Centro do sistema</h3><p>Base local e diagnóstico</p></div></div>
            <section className="status-grid">
              <div className="status-card"><div className="status-icon"><HardDrive size={18}/></div><div><span>ARMAZENAMENTO</span><strong>Local-first</strong><small>Sem conta ou nuvem obrigatória</small></div></div>
              <div className="status-card"><div className="status-icon"><ShieldCheck size={18}/></div><div><span>PRIVACIDADE</span><strong>Controle local</strong><small>Sem telemetria invasiva</small></div></div>
              <button className="status-card diagnostic-card" onClick={runDiagnostic}><div className="status-icon"><AppWindow size={18}/></div><div><span>DIAGNÓSTICO DO CORE</span><strong>Executar verificação <ArrowUpRight size={13}/></strong><small>{diagnostic}</small></div></button>
            </section>
          </> : <ModulePlaceholder id={active} onBack={() => setActive("overview")}/>}
          <footer><span>DIAMANDIS ONE <b>•</b> BUILT FOR YOUR DESKTOP</span><span><Clock3 size={12}/> VERSÃO DE FUNDAÇÃO 0.1.0</span></footer>
        </div>
      </main>
    </div>
  );
}

function ModuleCard({ icon: Icon, title, desc, meta, onClick }: { icon: LucideIcon; title: string; desc: string; meta: string; onClick: () => void }) {
  return <button className="module-card" onClick={onClick}><div className="module-card-top"><div className="module-icon"><Icon size={21}/></div><ArrowUpRight size={16} className="card-arrow"/></div><div className="module-meta">{meta}</div><h4>{title}</h4><p>{desc}</p><div className="card-link">ABRIR MÓDULO <ChevronRight size={13}/></div></button>;
}

function ModulePlaceholder({ id, onBack }: { id: ModuleId; onBack: () => void }) {
  const info: Record<ModuleId, { icon: LucideIcon; label: string; items: string[] }> = {
    overview: { icon: LayoutDashboard, label: "Visão geral", items: [] },
    files: { icon: FileSearch, label: "File Manager", items: ["Explorador de arquivos", "Localizador de duplicados", "Análise de arquivos grandes", "Renomeação em lote"] },
    toolbox: { icon: Image, label: "Toolbox", items: ["Conversor e redimensionador de imagens", "Gerador de QR Codes", "Ferramentas de texto", "Conversor de unidades"] },
    games: { icon: Gamepad2, label: "GameHub", items: ["Biblioteca unificada", "Detecção de launchers", "Favoritos e categorias", "Histórico de sessões"] },
    saves: { icon: HardDrive, label: "Save Center", items: ["Perfis de salvamento", "Backups manuais", "Histórico de versões", "Restauração assistida"] },
    settings: { icon: Settings2, label: "Configurações", items: ["Aparência e tema", "Preferências de inicialização", "Privacidade e permissões", "Sobre o aplicativo"] }
  };
  const data = info[id]; const Icon = data.icon;
  return <section className="placeholder"><div className="placeholder-icon"><Icon size={30}/></div><div className="eyebrow">MÓDULO PREPARADO</div><h2>{data.label}</h2><p>Esta área já está conectada à navegação. As funcionalidades serão implementadas em etapas, com testes próprios.</p><div className="planned-list">{data.items.map(item => <div key={item}><CheckCircle2 size={15}/>{item}</div>)}</div><button className="secondary-button" onClick={onBack}>Voltar ao dashboard</button></section>;
}

export default App;